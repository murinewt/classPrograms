package com.ssg.hashcode.algo;

import java.util.HashSet;

import com.ssg.hashcode.model.*;

public abstract class Algo {

	public abstract Output execute(Model model);
}
