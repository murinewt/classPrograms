# HashCode-2017
a multi language solution to the pizza problem statement 
