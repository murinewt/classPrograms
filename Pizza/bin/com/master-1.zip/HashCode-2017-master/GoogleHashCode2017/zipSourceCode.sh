#!/usr/bin/env bash
#removes an existing archive
rm googleHashCode_Pizza.*
#zip all the project code
zip -r googleHashCode_Pizza  .