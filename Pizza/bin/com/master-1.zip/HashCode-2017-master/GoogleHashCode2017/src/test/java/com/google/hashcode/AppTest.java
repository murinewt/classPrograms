package com.google.hashcode;

import org.junit.Test;

import java.io.IOException;

public class AppTest {

    @Test
    public void main() throws IOException {
        // App.main(new String[0]);
    }

}
