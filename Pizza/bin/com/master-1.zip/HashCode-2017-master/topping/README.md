# topping
An attempt to solve Google Hash Code 2017 practice round.
