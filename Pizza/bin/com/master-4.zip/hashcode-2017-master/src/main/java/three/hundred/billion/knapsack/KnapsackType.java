package three.hundred.billion.knapsack;

/**
 * Created by nikos on 24/2/2017.
 */
public enum KnapsackType {
    BnB, Dynamic, Greedy
}
