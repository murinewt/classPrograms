# hashcode-2017
Our solution to 2017 Google Hash Code challenge. It reached 2.35 million points (best 2.5 million) .
